import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:insurebuddy1/screens/login.dart';
import 'package:insurebuddy1/screens/signin.dart';
import 'dart:convert';
import 'package:insurebuddy1/screens/wishlist.dart';

class InsuranceDetails extends StatefulWidget {
  final String text;
  InsuranceDetails({Key key, @required this.text}) : super(key: key);

  TextEditingController _c;
  @override
  void initState() {
    _c = new TextEditingController();
  }

  _InsuranceDetailsState createState() => _InsuranceDetailsState();
}

class _InsuranceDetailsState extends State<InsuranceDetails> {
  @override
  Widget build(BuildContext context) {
    final Map<String, dynamic> insuranceDetail = json.decode(widget.text);
    print(insuranceDetail);

    return Scaffold(
      drawer: Drawer(
          child: Container(
              child: ListView(children: <Widget>[
        SizedBox(
          height: 100,
          //width: 100,
          child: DrawerHeader(
              decoration: BoxDecoration(color: Colors.grey[300]
                  //gradient: LinearGradient(colors: <Color>[Colors.cyan[200], Colors.cyan[600]])
                  ),
              child: Row(children: <Widget>[
                Align(
                    alignment: Alignment.center,
                    child: photoUrl != null
                        ? CircleAvatar(
                            radius: 40, backgroundImage: NetworkImage(photoUrl))
                        : SizedBox()),
                // Padding(padding: EdgeInsets.only(right: 10)),
              ])),
        ),
        SizedBox(height: 15),
        GestureDetector(
            onTap: () {},
            child: Container(
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(
                      Radius.circular(10.0),
                    ),
                    color: Colors.grey[300]),
                child: ListTile(
                  title: Text('Wishlist',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: Colors.black87,
                          fontSize: 18.0,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1.0)),
                ))),
        SizedBox(height: 25),
        GestureDetector(
            onTap: () {},
            child: Container(
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(
                      Radius.circular(10.0),
                    ),
                    color: Colors.grey[300]),
                child: ListTile(
                  title: Text('Settings',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: Colors.black87,
                          fontSize: 18.0,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1.0)),
                ))),
        SizedBox(height: 25),
        GestureDetector(
            onTap: () {},
            child: Container(
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(
                      Radius.circular(10.0),
                    ),
                    color: Colors.grey[300]),
                child: ListTile(
                  title: Text('My Profile',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: Colors.black87,
                          fontSize: 18.0,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1.0)),
                ))),
      ]))),
      // resizeToAvoidBottomInset: false,
      appBar: AppBar(
        title: Text('InsureBuddy'),
        backgroundColor: Colors.purpleAccent[700],
        actions: <Widget>[
          Padding(
            padding: EdgeInsets.only(top: 4, bottom: 4, right: 8),
            child: photoUrl != null
                ? CircleAvatar(backgroundImage: NetworkImage(photoUrl))
                : SizedBox(),
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Card(
          margin: EdgeInsets.all(20),
          elevation: 10,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15.0),
          ),
          color: Colors.grey[300],
          child: Column(
            children: [
              Padding(
                padding: EdgeInsets.only(top: 10, bottom: 10),
                //padding: EdgeInsets
                child: SizedBox(
                  height: 50,
                  width: 200,
                  child: Image(
                    fit: BoxFit.fitWidth,
                    image: AssetImage(
                      'images/logo.jpg',
                    ),
                    height: 10,
                  ),
                ),
              ),
              SizedBox(height: 10),
              Container(
                child: Text(
                  'INSURANCE DETAILS',
                  style: TextStyle(
                      color: Colors.black,
                      fontSize: 20,
                      fontWeight: FontWeight.bold),
                ),
              ),
              SizedBox(height: 20),
              Text(
                'Coverage : ${insuranceDetail['policyCoverage']}',
                // 'Coverage :',
                textAlign: TextAlign.start,
                style: TextStyle(
                  fontSize: 16,
                  // fontWeight: FontWeight.bold
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 50.0),
                child: ListTile(
                  leading: Icon(Icons.calendar_today),
                  title: Text('Tenure : ${insuranceDetail['policyTenure']}'),
                ),
              ),
              Card(
                margin: EdgeInsets.all(10),
                color: Colors.orange[800],
                elevation: 6,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10.0),
                ),
                child: Padding(
                  padding: EdgeInsets.all(10),
                  child: Text(
                    'Policy Premium : ${insuranceDetail['policyPremium']}',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
              Card(
                margin: EdgeInsets.all(10),
                color: Colors.orange[800],
                elevation: 6,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10.0),
                ),
                child: Padding(
                  padding: EdgeInsets.all(10),
                  child: Text(
                    'Policy Amount : ${insuranceDetail['policyAmount']}',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
              Card(
                margin: EdgeInsets.all(10),
                color: Colors.orange[800],
                elevation: 6,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10.0),
                ),
                child: Padding(
                  padding: EdgeInsets.all(15),
                  child: GestureDetector(
                    onTap: () {
                      wishListData.add(insuranceDetail);
                      Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                              builder: (context) => WishList(
                                  text: ''
                                      '{'
                                      '   "policyAmount":"${insuranceDetail['policyAmount']}",'
                                      '   "policyCoverage":"${insuranceDetail['policyCoverage']}",'
                                      '   "policyNumber":"${insuranceDetail['policyNumber']}",'
                                      '   "policyPremium":"${insuranceDetail['policyPremium']}",'
                                      '   "policyTenure":"${insuranceDetail['policyTenure']}"'
                                      '}'
                                      '')));
                    },
                    child: Text(
                      'Add to Wishlist',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                ),
              ),
              Row(
                children: [
                  Padding(
                    padding: EdgeInsets.only(left: 10, right: 10),
                    child: Text(
                      'Give Rating',
                      style: TextStyle(color: Colors.black, fontSize: 16),
                    ),
                  ),
                  RatingBar.builder(
                    initialRating: 3,
                    minRating: 1,
                    direction: Axis.horizontal,
                    allowHalfRating: true,
                    itemCount: 5,
                    itemPadding: EdgeInsets.symmetric(horizontal: 1.0),
                    itemBuilder: (context, _) => Icon(
                      Icons.star,
                      color: Colors.amber,
                    ),
                    onRatingUpdate: (rating) {
                      print(rating);
                    },
                  ),
                ],
              ),
              Card(
                color: Color(0xFFBDBDBD),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10.0),
                ),
                margin: EdgeInsets.all(20),
                elevation: 6,
                child: Column(
                  children: [
                    TextField(
                      keyboardType: TextInputType.number,
                      onChanged: (v) => setState(() {}),
                      textAlign: TextAlign.center,
                      decoration: InputDecoration(
                        fillColor: Color(0xFFBDBDBD),
                        hintStyle: TextStyle(
                            fontSize: 20, fontWeight: FontWeight.bold),
                        hintText: 'Write a review',
                        border: InputBorder.none,
                        contentPadding: EdgeInsets.all(4.0),
                      ),
                    ),
                    SizedBox(height: 20),
                    RaisedButton(
                      color: Colors.orange[800],
                      child: Text('Submit'),
                      elevation: 6,
                      onPressed: () {},
                    ),
                    SizedBox(height: 10),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
