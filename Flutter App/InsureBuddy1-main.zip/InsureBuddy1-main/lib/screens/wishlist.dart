import 'package:flutter/material.dart';
import 'package:insurebuddy1/screens/insurancedetails.dart';
import 'dart:convert';
import 'package:insurebuddy1/screens/login.dart';
import 'package:insurebuddy1/screens/signin.dart';

class WishList extends StatefulWidget {
  final String text;
  WishList({Key key, @required this.text}) : super(key: key);

  @override
  _WishListState createState() => _WishListState();
}

class _WishListState extends State<WishList> {
  @override
  Widget build(BuildContext context) {
    // final Map<String, dynamic> insuranceDetail = json.decode(widget.text);

    return Scaffold(
      appBar: AppBar(
        title: Text('Wish List'),
        backgroundColor: Colors.purpleAccent[700],
        actions: <Widget>[
          Padding(
            padding: EdgeInsets.only(top: 4, bottom: 4, right: 8),
            child: photoUrl != null
                ? CircleAvatar(backgroundImage: NetworkImage(photoUrl))
                : SizedBox(),
          ),
        ],
      ),
      body: Column(
          children: wishListData
              .map(
                (insuranceDetail) => GestureDetector(
                  onTap: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => InsuranceDetails(
                                text: ''
                                    '{'
                                    '   "policyAmount":"${insuranceDetail['policyAmount']}",'
                                    '   "policyCoverage":"${insuranceDetail['policyCoverage']}",'
                                    '   "policyNumber":"${insuranceDetail['policyNumber']}",'
                                    '   "policyPremium":"${insuranceDetail['policyPremium']}",'
                                    '   "policyTenure":"${insuranceDetail['policyTenure']}"'
                                    '}'
                                    '')));
                  },
                  child: Padding(
                    padding: EdgeInsets.fromLTRB(10, 10, 10, 10),
                    child: Card(
                      elevation: 10,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15.0),
                      ),
                      color: Colors.grey[300],
                      child: Column(
                        children: <Widget>[
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: <Widget>[
                              Padding(
                                padding: EdgeInsets.only(top: 10, bottom: 10),
                                child: SizedBox(
                                  height: 50,
                                  width: 200,
                                  child: Image(
                                    fit: BoxFit.fitWidth,
                                    image: AssetImage(
                                      'images/logo.jpg',
                                    ),
                                    height: 10,
                                  ),
                                ),
                              ),
                              Padding(
                                padding: EdgeInsets.only(top: 10, bottom: 10),
                                child: Card(
                                  margin: EdgeInsets.all(10),
                                  color: Colors.orange[800],
                                  elevation: 6,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10.0),
                                  ),
                                  child: Padding(
                                    padding: EdgeInsets.all(10),
                                    child: Text(
                                      '${insuranceDetail['policyAmount']}',
                                      textAlign: TextAlign.center,
                                      style: TextStyle(color: Colors.white),
                                    ),
                                  ),
                                ),
                              )
                            ],
                          ),
                          Text(
                            'Coverage : ${insuranceDetail['policyCoverage']}',
                            textAlign: TextAlign.left,
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          ListTile(
                            leading: Icon(Icons.calendar_today),
                            title: Text(
                              'Insurance Tenure : ${insuranceDetail['policyTenure']}',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              )
              .toList()),
    );
  }
}
