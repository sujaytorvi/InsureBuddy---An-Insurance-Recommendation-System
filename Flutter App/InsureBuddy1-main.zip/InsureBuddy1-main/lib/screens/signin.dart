import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'dart:io';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:insurebuddy1/screens/login.dart';
import 'package:shared_preferences/shared_preferences.dart';

String name, email, password, photoUrl;

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final GoogleSignIn _googleSignIn = GoogleSignIn();
  final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;

  Future<String> googleSignIn() async {
    final GoogleSignInAccount googleSignInAccount =
        await _googleSignIn.signIn();
    final GoogleSignInAuthentication googleSignInAuthentication =
        await googleSignInAccount.authentication;
    final AuthCredential authCredential = GoogleAuthProvider.credential(
        accessToken: googleSignInAuthentication.accessToken,
        idToken: googleSignInAuthentication.idToken);

    final UserCredential userCredential =
        await _firebaseAuth.signInWithCredential(authCredential);
    final User user = userCredential.user;
    assert(user.photoURL != null);
    assert(user.displayName != null);
    assert(user.email != null);
    SharedPreferences prefs = await SharedPreferences.getInstance();

    setState(() {
      name = user.displayName;
      email = user.email;
      photoUrl = user.photoURL;
    });

    final User currentUser = _firebaseAuth.currentUser;
    assert(currentUser.uid == user.uid);
    return 'Logged In';
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
        onWillPop: () => exit(0),
        child: Scaffold(
            backgroundColor: Colors.purple,
            body: Center(
                child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[_GoogleSignInButton()],
            ))));
  }

  _GoogleSignInButton() {
    return Builder(
        builder: (context) => Column(children: <Widget>[
              Text(
                'WELCOME TO INSUREBUDDY',
                style: TextStyle(fontSize: 30, color: Colors.red),
                textAlign: TextAlign.center,
              ),
              //Container(child: Image(image: AssetImage('images/chatlogo.png'))),

              SizedBox(height: 20),
              Container(
                margin: EdgeInsets.only(left: 50, right: 50),
                height: 50,
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.all(Radius.circular(20))),
                child: Row(
                  children: <Widget>[
                    Padding(padding: EdgeInsets.only(left: 10)),
                    CircleAvatar(
                      backgroundImage: AssetImage('images/google.jpg'),
                    ),
                    Padding(padding: EdgeInsets.only(left: 15)),
                    GestureDetector(
                        onTap: () => googleSignIn().whenComplete(() async {
                              await FirebaseFirestore.instance
                                  .collection("user")
                                  .add({
                                'email': email,
                                'name': name,
                                'photoUrl': photoUrl,
                              }).then((value) {
                                print(value.id);
                              });

                              Navigator.pushReplacement(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => LoginPage()));
                            }),
                        child: Text(
                          'Sign in with Google',
                          style: TextStyle(fontSize: 18),
                        ))
                  ],
                ),
              ),
            ]));
  }
}
