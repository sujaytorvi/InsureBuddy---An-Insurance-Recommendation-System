import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter/widgets.dart';
import 'package:insurebuddy1/request.dart';
import 'package:insurebuddy1/screens/wishlist.dart';
import 'login.dart';
import 'package:insurebuddy1/screens/insurancedetails.dart';
import 'package:insurebuddy1/screens/login.dart';
import 'dart:convert';
import 'package:insurebuddy1/screens/signin.dart';

import 'package:http/http.dart' as http;

class InsuranceScreen extends StatefulWidget {
  final String text;

  // final Map<String, dynamic> data = json.encode({this.text});
  InsuranceScreen({Key key, @required this.text}) : super(key: key);
  @override
  _InsuranceScreenState createState() => _InsuranceScreenState();
}

class _InsuranceScreenState extends State<InsuranceScreen> {
  String url = '';
  String policyAmount;
  List<Map<String, dynamic>> distributions = [];

  //Future Getdata (url) async {
  // final data = await http.post("http://127.0.0.1/",data: {});
  // return data;
  //}

  //String QueryText = 'Query';
  int _selectedDrawerIndex = 0;

  _getDrawerItemWidget(int pos) {
    switch (pos) {
      case 0:
        return new WishList(text: '');
      case 1:
      // to do: handle settings screen
      // return new SecondFragment();
      case 2:
      // todo: handle my profile screen
      // return new ThirdFragment();

      case 3:
      // todo: handle FAQ screen
      // return new FAQ();
      default:
        return new Text("Error");
    }
  }

  int i;
  @override
  Widget build(BuildContext context) {
    // print(json.decode(widget.text)[0]);

    // final Map<String, dynamic> a = insuranceData[2];
    // print(insuranceData[2]);
    final children = <Widget>[];
    for (int i = 0; i < insuranceData?.length ?? 0; i++) {
      children.add(
        GestureDetector(
          onTap: () {
            // policyAmount = insuranceData[0]['policyAmount'];
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => InsuranceDetails(
                        text: ''
                            '{'
                            '   "policyAmount":"${insuranceData[i]['policyAmount']}",'
                            '   "policyCoverage":"${insuranceData[i]['policyCoverage']}",'
                            '   "policyNumber":"${insuranceData[i]['policyNumber']}",'
                            '   "policyPremium":"${insuranceData[i]['policyPremium']}",'
                            '   "policyTenure":"${insuranceData[i]['policyTenure']}"'
                            '}'
                            '')));
          },
          child: Padding(
            padding: EdgeInsets.fromLTRB(10, 10, 10, 10),
            child: Card(
              elevation: 10,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15.0),
              ),
              color: Colors.grey[300],
              child: Column(
                children: <Widget>[
                  //Text('policyAmount - ${insuranceData[i]['policyAmount']}'),
                  //Text('policyCoverage - ${insuranceData[i]['policyCoverage']}'),
                  // Text('policyNumber - ${insuranceData[i]['policyNumber']}'),
                  //Text('policyPremium - ${insuranceData[i]['policyPremium']}'),
                  //Text('policyTenure - ${insuranceData[i]['policyTenure']}'),

                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: <Widget>[
                      //image
                      Padding(
                        padding: EdgeInsets.only(top: 10, bottom: 10),
                        //padding: EdgeInsets
                        child: SizedBox(
                          height: 50,
                          width: 200,
                          child: Image(
                            fit: BoxFit.fitWidth,
                            image: AssetImage(
                              'images/logo.jpg',
                            ),
                            height: 10,
                          ),
                        ),
                      ),

                      //amount
                      Padding(
                        padding: EdgeInsets.only(top: 10, bottom: 10),
                        child: Card(
                          margin: EdgeInsets.all(10),
                          color: Colors.orange[800],
                          elevation: 6,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10.0),
                          ),
                          child: Padding(
                            padding: EdgeInsets.all(10),
                            child: Text(
                              '${insuranceData[i]['policyAmount']}',
                              textAlign: TextAlign.center,
                              style: TextStyle(color: Colors.white),
                            ),
                          ),
                        ),
                      )
                    ],
                  ),

                  Text(
                    'Coverage : ${insuranceData[i]['policyCoverage']}',
                    textAlign: TextAlign.left,
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),

                  ListTile(
                    leading: Icon(Icons.calendar_today),
                    title: Text(
                      'Insurance Tenure : ${insuranceData[i]['policyTenure']}',
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    }

    return Scaffold(
        drawer: Drawer(
            child: Container(
                child: ListView(children: <Widget>[
          SizedBox(
            height: 100,
            //width: 100,
            child: DrawerHeader(
                decoration: BoxDecoration(color: Colors.grey[300]
                    //gradient: LinearGradient(colors: <Color>[Colors.cyan[200], Colors.cyan[600]])
                    ),
                child: Row(children: <Widget>[
                  Align(
                      alignment: Alignment.center,
                      child: photoUrl != null
                          ? CircleAvatar(
                              radius: 40,
                              backgroundImage: NetworkImage(photoUrl))
                          : SizedBox()),
                  // Padding(padding: EdgeInsets.only(right: 10)),
                ])),
          ),
          SizedBox(height: 15),
          GestureDetector(
              onTap: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => WishList(text: '')));

                // Future.delayed(const Duration(milliseconds: 500), () {
                //   Navigator.of(context).pop();
                //   setState(() {});
                // });
              },
              child: Container(
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.all(
                        Radius.circular(10.0),
                      ),
                      color: Colors.grey[300]),
                  child: ListTile(
                    title: Text('Wishlist',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            color: Colors.black87,
                            fontSize: 18.0,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 1.0)),
                  ))),
          SizedBox(height: 25),
          GestureDetector(
              onTap: () {},
              child: Container(
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.all(
                        Radius.circular(10.0),
                      ),
                      color: Colors.grey[300]),
                  child: ListTile(
                    title: Text('Settings',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            color: Colors.black87,
                            fontSize: 18.0,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 1.0)),
                  ))),
          SizedBox(height: 25),
          GestureDetector(
              onTap: () {},
              child: Container(
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.all(
                        Radius.circular(10.0),
                      ),
                      color: Colors.grey[300]),
                  child: ListTile(
                    title: Text('My Profile',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            color: Colors.black87,
                            fontSize: 18.0,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 1.0)),
                  ))),
          SizedBox(height: 25),
          GestureDetector(
              onTap: () {},
              child: Container(
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.all(
                        Radius.circular(10.0),
                      ),
                      color: Colors.grey[300]),
                  child: ListTile(
                    title: Text('FAQs',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            color: Colors.black87,
                            fontSize: 18.0,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 1.0)),
                  ))),
          SizedBox(height: 25),
        ]))),
        appBar: AppBar(
          actions: <Widget>[
            Padding(
              padding: EdgeInsets.only(top: 4, bottom: 4, right: 8),
              child: photoUrl != null
                  ? CircleAvatar(backgroundImage: NetworkImage(photoUrl))
                  : SizedBox(),
            ),
          ],
          backgroundColor: Colors.purpleAccent[700],
          title: Text(
            'InsureBuddy',
            textAlign: TextAlign.center,
          ),
        ),
        body: ListView(children: children));
  }
}
