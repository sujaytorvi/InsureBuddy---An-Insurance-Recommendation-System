import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:insurebuddy1/screens/insurance.dart';
import 'package:insurebuddy1/request.dart';
import 'package:insurebuddy1/screens/signin.dart';
import 'dart:convert';
import 'package:dropdown_search/dropdown_search.dart';
import 'package:insurebuddy1/screens/wishlist.dart';

Fetch fetch = Fetch();

List<dynamic> wishListData = [];

List insuranceData = [];

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

var gender = 'Male';
var marital_status = 'Married';
var age = 'Below_25_Years';
var occupation = 'Corporate_Employee';
var income = '0_5_lac';
var ailment = 'No';
String selected;

class _LoginPageState extends State<LoginPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      drawer: Drawer(
          child: Container(
              child: ListView(children: <Widget>[
        SizedBox(
          height: 100,
          child: DrawerHeader(
              decoration: BoxDecoration(color: Colors.grey[300]),
              child: Row(children: <Widget>[
                Align(
                    alignment: Alignment.center,
                    child: photoUrl != null
                        ? CircleAvatar(
                            radius: 40, backgroundImage: NetworkImage(photoUrl))
                        : SizedBox()),
              ])),
        ),
        SizedBox(height: 15),
        GestureDetector(
            onTap: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => WishList(text: '')));
            },
            child: Container(
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(
                      Radius.circular(10.0),
                    ),
                    color: Colors.grey[300]),
                child: ListTile(
                  title: Text('Wishlist',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: Colors.black87,
                          fontSize: 18.0,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1.0)),
                ))),
        SizedBox(height: 25),
        GestureDetector(
            onTap: () {},
            child: Container(
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(
                      Radius.circular(10.0),
                    ),
                    color: Colors.grey[300]),
                child: ListTile(
                  title: Text('Settings',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: Colors.black87,
                          fontSize: 18.0,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1.0)),
                ))),
        SizedBox(height: 25),
        GestureDetector(
            onTap: () {},
            child: Container(
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(
                      Radius.circular(10.0),
                    ),
                    color: Colors.grey[300]),
                child: ListTile(
                  title: Text('My Profile',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: Colors.black87,
                          fontSize: 18.0,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1.0)),
                ))),
        SizedBox(height: 25),
        GestureDetector(
            onTap: () {},
            child: Container(
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(
                      Radius.circular(10.0),
                    ),
                    color: Colors.grey[300]),
                child: ListTile(
                  title: Text('FAQs',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: Colors.black87,
                          fontSize: 18.0,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1.0)),
                ))),
        SizedBox(height: 25),
        GestureDetector(
            onTap: () {},
            child: Container(
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(
                      Radius.circular(10.0),
                    ),
                    color: Colors.grey[300]),
                child: GestureDetector(
                  onTap: () {
                    //signOut();
                    Navigator.pushReplacement(context,
                        MaterialPageRoute(builder: (context) => LoginScreen()));
                  },
                  child: ListTile(
                    title: Text('Sign Out',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            color: Colors.black87,
                            fontSize: 18.0,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 1.0)),
                  ),
                ))),
      ]))),
      appBar: AppBar(
        actions: <Widget>[
          Padding(
            padding: EdgeInsets.only(top: 4, bottom: 4, right: 8),
            child: photoUrl != null
                ? CircleAvatar(backgroundImage: NetworkImage(photoUrl))
                : SizedBox(),
          ),
        ],
        backgroundColor: Colors.purpleAccent[700],
        title: Text(
          'InsureBuddy',
          textAlign: TextAlign.center,
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            SizedBox(height: 10),
            Text(
              'Enter Details',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 25),
            Padding(
              padding: EdgeInsets.only(left: 20, right: 20),
              //padding: const EdgeInsets.fromLTRB(15, 3.0, 15, 3.0),
              child: Material(
                elevation: 8,
                borderRadius: BorderRadius.circular(20),
                child: Container(
                  height: 50,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: Colors.grey[200],
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Padding(
                    padding: EdgeInsets.only(top: 12),
                    child: Text(
                      name ?? '',
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(height: 25),
            Padding(
              padding: EdgeInsets.only(left: 20, right: 20),
              child: Material(
                elevation: 8,
                borderRadius: BorderRadius.circular(20),
                child: Container(
                  height: 50,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    //boxShadow: [BoxShadow(color: Colors.grey[400], blurRadius: 10.0, spreadRadius: 1.0, offset: Offset(2.0, 2.0))],
                    color: Colors.grey[200],
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Padding(
                    padding: EdgeInsets.only(top: 12),
                    child: Text(
                      email ?? '',
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(height: 20),
            Padding(
              padding: const EdgeInsets.fromLTRB(15, 3.0, 15, 3.0),
              child: DropdownSearch(
                items: ["Male", "Female"],
                label: "Gender",
                selectedItem: "Male",
                onChanged: (value) async {
                  setState(() => gender = value);
                },
                validator: (String item) {
                  if (item == null)
                    return "Required field";
                  //else if (item == "Brazil")
                  // return "Invalid item";
                  else
                    return null;
                },
              ),
            ),
            SizedBox(height: 15),
            Padding(
              padding: const EdgeInsets.fromLTRB(15, 3.0, 15, 3.0),
              child: DropdownSearch(
                items: ["Married", "Unmarried"],
                label: "Marital Status",
                selectedItem: "Married",
                onChanged: (value) async {
                  setState(() => marital_status = value);
                },
                validator: (String item) {
                  if (item == null)
                    return "Required field";
                  else
                    return null;
                },
              ),
            ),
            SizedBox(height: 15),
            Padding(
              padding: const EdgeInsets.fromLTRB(15, 3.0, 15, 3.0),
              child: DropdownSearch(
                items: [
                  "Below_25_Years",
                  "25_40_Years",
                  "41_60_Years",
                  "Above_60_Years"
                ],
                label: "Age",
                selectedItem: "Below_25_Years",
                onChanged: (value) async {
                  setState(() => age = value);
                },
                validator: (String item) {
                  if (item == null)
                    return "Required field";
                  else
                    return null;
                },
              ),
            ),
            SizedBox(height: 15),
            Padding(
              padding: const EdgeInsets.fromLTRB(15, 3.0, 15, 3.0),
              child: DropdownSearch(
                items: [
                  "Corporate_Employee",
                  "Enterpreneur",
                  "Medical_Professional",
                  "Self_Employed"
                ],
                label: "Occupation",
                selectedItem: "Corporate_Employee",
                onChanged: (value) async {
                  setState(() => occupation = value);
                },
                validator: (String item) {
                  if (item == null)
                    return "Required field";
                  else
                    return null;
                },
              ),
            ),
            SizedBox(height: 15),
            Padding(
              padding: const EdgeInsets.fromLTRB(15, 3.0, 15, 3.0),
              child: DropdownSearch(
                items: [
                  "0_5_lac",
                  "5_10_lac",
                  "10_20_lac",
                  "20_30_lac",
                  "30_40_lac",
                  "40_50_lac"
                ],
                label: "Income(per annum)",
                selectedItem: "0_5_lac",
                onChanged: (value) async {
                  setState(() => income = value);
                },
                validator: (String item) {
                  if (item == null)
                    return "Required field";
                  else
                    return null;
                },
              ),
            ),
            SizedBox(height: 15),
            Padding(
              padding: const EdgeInsets.fromLTRB(15, 3.0, 15, 3.0),
              child: DropdownSearch(
                items: ["Yes", "No"],
                label: "Ailment",
                selectedItem: "No",
                onChanged: (value) async {
                  setState(() => ailment = value);
                },
                validator: (String item) {
                  if (item == null)
                    return "Required field";
                  else
                    return null;
                },
              ),
            ),
            SizedBox(height: 15),
            RaisedButton(
                elevation: 8,
                child: Text('Submit'),
                onPressed: () async {
                  // Navigator.pushReplacement(context, MaterialPageRoute(
                  //     builder: (context) => InsuranceScreen()
                  // )
                  // );
                  // print('data');
                  print('Before Request');
                  print(gender);
                  print(marital_status);
                  print(age);
                  print(occupation);
                  print(income);
                  print(ailment);

                  // var check =
                  //     'https://insure-buddy.herokuapp.com/getpolicy?gender=${gender}&marital_status=${marital_status}&age=${age}&occupation=${occupation}&income=${income}&ailment=${ailment}';
                  // print(check);
                  final data = await fetch.get(
                      api:
                          'https://insure-buddy.herokuapp.com/getpolicy?gender=${gender}&marital_status=${marital_status}&age=${age}&occupation=${occupation}&income=${income}&ailment=${ailment}');
                  // print(name);
                  // print(email);
                  //

                  // print(json.encode(data));

                  // print(data[0]);

                  print(data);
                  String text = json.encode(data ?? '');
                  insuranceData = data;

                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) =>
                              InsuranceScreen(text: json.encode(data ?? ''))));
                })
          ],
        ),
      ),
    );
  }
}
