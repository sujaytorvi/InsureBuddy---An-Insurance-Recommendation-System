import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';

class Fetch {
  // String url = 'http://192.168.0.160:83/api';
  // String url = 'http://13.233.9.249:85/api';
  String url = 'http://38.17.52.115:89/api';
  final http.Client client = new http.Client();
  String token;
  String apiKey;

  Map<String, String> get defaultHeaders {
    return {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    };
  }

  Map<String, String> get headers {
    if (token == '') {
      return defaultHeaders;
    }
    return {
      'Authorization': 'Bearer $token',
      ...defaultHeaders,
    };
  }

  Future<List<dynamic>> get({
    String api = '',
  }) async {
    http.Response response = await client.get(
      Uri.encodeFull('$api'),
      headers: headers,
    );
    // print(json.decode(response.body)[0]);
    // return json.decode(response.body);
    // print(giveResponse(response));
    // return giveResponse(response);
    return json.decode(response.body);
  }

  Future<Map<String, dynamic>> post(
      {String api, Map<String, dynamic> data = const {}, Print(data)}) async {
    http.Response response = await client.post(
      // Uri.encodeFull('$url/$api'),
      Uri.encodeFull('$api'),
      // Uri.https('jsonplaceholder.typicode.com',api),
      // headers: headers,
      body: json.encode(data),
    );
    print(data);
    // print(json.decode(response.body));
    print(response.statusCode);
    // return giveResponse(response);
  }

  Map<String, dynamic> giveResponse(http.Response response) {
    return json.decode(response.body);
  }
}
